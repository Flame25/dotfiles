public class  Main {
	public static void main(String args[]) {
		//Impostor
		RedAstronaut r1 = new RedAstronaut("red1");
		RedAstronaut r2 = new RedAstronaut("red2");
		//Crewmate
		BlueAstronaut b1 = new BlueAstronaut("blue1", 100, 10, 20);
		BlueAstronaut b2 = new BlueAstronaut("blue2");
		BlueAstronaut b3 = new BlueAstronaut("blue3");
		BlueAstronaut b4 = new BlueAstronaut("blue4");
		r1.emergencyMeeting();
		r1.freeze(b4);
		r1.emergencyMeeting();
		r1.sabotage(b4);
		r2.sabotage(b4);
		r2.freeze(b4);
		System.out.println(r1.toString());
		System.out.println(r2.toString());
		
		System.out.println(b1.toString());
		System.out.println(b2.toString());
		System.out.println(b3.toString());
		System.out.println(b4.toString());
	}
}
