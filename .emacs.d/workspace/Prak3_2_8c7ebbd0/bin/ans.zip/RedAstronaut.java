import java.util.Arrays;

// Lengkapi definisi class
public class RedAstronaut extends Player implements Impostor {
	private String skill;
	// Atribut skill bertipe data String
    // Atribut DEFAULT_SKILL bertipe data String dengan nilai "experienced"
	final String DEFAULT_SKILL = "experienced";
    public RedAstronaut(String name) {
		// Panggil constructor dengan parameter name, DEFAULT_SUS_LEVEL, dan DEFAULT_
		super(name, DEFAULT_SUS_LEVEL);
		this.skill = DEFAULT_SKILL;
		super.setFrozen(false);
	}

    public RedAstronaut(String name, int susLevel, String skill) {
        // Panggil constructor dari superclass dengan parameter name dan susLevel
		// Isi variabel skill dengan parameter skill yang sudah diubah menjadi lowercase
		super(name, susLevel);
		this.skill = skill.toLowerCase(); 
		super.setFrozen(false);
	}

    /*
        * Player yang frozen tidak bisa melakukan emergency meeting.
g       * Mengadakan meeting dan memilih untuk mengeluarkan (freeze) Player yang paling mencurigakan, hanya mempertimbangkan Player yang tidak frozen
            * Player dengan susLevel tertinggi (yang BUKAN Impostor yang saat ini yang memanggil pertemuan) akan dituduh sebagai Impostor dan akan dikeluarkan
            * Jika dua pemain memiliki susLevel tertinggi yang sama, tidak ada pemain yang akan dikeluarkan.
            * **Hint**: Tidak perlu mengiterasi seluruh array.
        * Pastikan untuk mengubah variabel frozen dari pemain menjadi true saat mengeluarkan pemain (jangan memanggil metode "freeze"!)
        * Di akhir pemungutan suara, periksa apakah permainan telah berakhir menggunakan metode yang disediakan di Player.java
        * Tidak mengembalikan apapun
    */
	public void emergencyMeeting() {
		if(isFrozen()){
			return;
		}
		int cnt = 0;
		Player[] players = super.getPlayers();
		int max_suslevel = -999;
		for (Player p : players) {
			if (p.getSusLevel() > max_suslevel && !p.isFrozen()){
				max_suslevel = p.getSusLevel();
			}
		}

		Player target = this;
		for (Player p : players) {
			if (p.getSusLevel() == max_suslevel && !p.isFrozen()){
				cnt++; 
				target = p; 
			}
		}

		if (cnt == 1)
			target.setFrozen(true);
		gameOver();
	}
    /*
        * Mengimplementasikan metode yang disediakan di antarmuka Impostor.
        * Tidak mungkin untuk melakukan freeze Impostor lain, dan Impostor yang frozen tidak dapat mencoba untuk melakukan freeze. Jika Player yang diberikan Impostor, metode harus berakhir. Melakukan freeze pada Player yang sudah beku juga tidak berpengaruh apa-apa.
        * Freeze berhasil jika susLevel RedAstronaut lebih rendah dari Player tersebut
        * Jika freeze tidak berhasil, susLevel RedAstronaut berlipat ganda (kalikan susLevel saat ini dengan 2)
        * Ingat untuk mengubah nilai boolean frozen untuk Crewmate sesuai kebutuhan.
        * Setelah percobaan freeze, periksa apakah permainan telah berakhir menggunakan metode yang disediakan di Player.java
        * Tidak mengembalikan apapun
    */
	public void freeze(Player p) {
		if (this.isFrozen() || p.isFrozen() || p instanceof Impostor){
			gameOver();
			return;
		}

		else if (p.getSusLevel() > this.getSusLevel()) {
			p.setFrozen(true);
		}
		else {
			this.setSusLevel(getSusLevel() * 2);
		}
		gameOver();
    }

    /*
        * Tidak mungkin menyabotase Impostor lain, dan Impostor yang frozen tidak dapat menyabotase. Menyabotase Player yang frozen tidak akan berpengaruh apa-apa.
        * Jika susLevel Impostor di bawah 20, mereka meningkatkan susLevel Crewmate sebesar 50%
        * Jika tidak, mereka hanya bisa meningkatkan susLevel Crewmate sebesar 25%
        * (Catatan: Dalam kedua kasus, susLevel Crewmate dibulatkan ke bawah ke nilai int terdekat)
        * Tidak mengembalikan apapun
    */
	public void sabotage(Player p) {
		if (this.isFrozen() || p.isFrozen() || p instanceof Impostor)
			return;
		else if (this.getSusLevel() < 20) {
			p.setSusLevel(getSusLevel() + getSusLevel() /2);
		}
		else {
			p.setSusLevel(getSusLevel() + getSusLevel() /4);
		}

}

    /*
	    * Dua Red sama jika mereka keduanya memiliki nama, frozen, susLevel, dan skill yang sama
	    * Mengembalikan sebuah boolean
	*/
	@Override
	public boolean equals(Object o) {
		RedAstronaut p = (RedAstronaut) o;
		if (p instanceof Impostor) {
			return super.equals(o) && skill.equals(p.skill);
		}
		else {
			return false;
		}
	}

    /*
	    Mengembalikan String yang menggambarkan RedAstronaut sebagai berikut:
	    * `"My name is [name], and I have a `susLevel` of [susLevel]. I am currently (frozen / not frozen). I am an [skill] player!"`
	    * Jika susLevel lebih besar dari 15, kembalikan keluaran dalam huruf kapital semua. (Hint: toUppercase)
	    * (Note: gantikan nilai dalam tanda kurung [] dengan nilai sebenarnya)
	    * Anda harus menggunakan metode toString() dari kelas Player.
	*/
	@Override
	public String toString() {
		if(getSusLevel() > 15)
			return (super.toString() + " I am an " + skill + " player!").toUpperCase();
		else
			return (super.toString() + " I am an " + skill + " player!");

    }
}
