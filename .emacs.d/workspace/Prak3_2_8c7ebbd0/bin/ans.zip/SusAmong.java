import java.util.Scanner;

public class SusAmong {
   public static void main(String args[]){
	   Player[] allPlayers = Player.getPlayers();
	   Scanner scanner = new Scanner(System.in);
	   int players = scanner.nextInt();
	   int imposor = scanner.nextInt();
	   int commands = scanner.nextInt();
	   int completedTask = 0; 
	   int playersFrozen = 0; 
	   int emergencyMeetingCalled = 0; 
	   if(commands == 1){
		   int index = scanner.nextInt();
		   if(allPlayers[index] instanceof BlueAstronaut){
			   BlueAstronaut tempAstronaut = (BlueAstronaut) allPlayers[index]; 
			   tempAstronaut.completeTask();
			   if(tempAstronaut.getNumTask() == 0){
				   completedTask++; 
			   }
		   }
	   }
	   else if(commands == 2){
		   int index_red = scanner.nextInt();
		   int index_blue = scanner.nextInt();
		   
		   if(allPlayers[index_red] instanceof RedAstronaut && allPlayers[index_blue] instanceof BlueAstronaut){
			   RedAstronaut impostor = (RedAstronaut) allPlayers[index_red];
			   impostor.freeze(allPlayers[index_blue]);
		   }
	   }
   }
}
   
