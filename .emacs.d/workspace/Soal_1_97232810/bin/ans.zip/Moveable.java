public interface Moveable {
	public void moveTo(GeoLoc newLoc);
}
