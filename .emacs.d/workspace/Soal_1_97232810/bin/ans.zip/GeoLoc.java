public class GeoLoc{
	private float lat; 
	private float lon; 
	private int alt;
	
	GeoLoc(float lat, float lon, int alt) {
		this.alt = alt;
		this.lat = lat;
		this.lon = lon;
	}

	public void setLoc(float lat, float lon, int alt){
		this.alt = alt; 
		this.lat = lat; 
		this.lon = lon; 
	}
	public int getAlt() {
		return alt;
	}
	public float getLon() {
		return lon;
	}
	public float getLat() {
		return lat;
	}
}
