public class MainVehicle {
	public static void main(String args[]) {
		GeoLoc newLoc = new GeoLoc(0, 0, 0);
		Drone drone = new Drone(newLoc);
		// TODO: Test Semua Fungsi
	}
}
