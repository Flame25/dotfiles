public abstract class Vehicle implements Moveable {
	private GeoLoc loc;
	public int speed; //Ketika di inisiasi Vehicle dalam keadaan diam;
	private static int numVehicle = 0;

	Vehicle(GeoLoc loc) {
		this.loc = loc;
		this.speed = 0;
		numVehicle++; 
	}

	public GeoLoc getLocation() {
		return loc;
	}

	public abstract void accelerate();

	public abstract void decelerate();
	
	public int getNumVehicle() {
		return numVehicle;
	}
	@Override
	public void moveTo(GeoLoc newLoc) {
		loc.setLoc(newLoc.getLat(), newLoc.getLon(), newLoc.getAlt());
	}
}

