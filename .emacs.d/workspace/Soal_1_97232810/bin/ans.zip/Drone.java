public class Drone extends Vehicle {
	Drone(GeoLoc loc) {
		super(loc);
	}
	@Override
	public void accelerate() {
		super.speed++;
	}
	@Override
	public void decelerate() {
		super.speed--;
	}

	public void climb() {
		GeoLoc tempLoc = super.getLocation();
		int newAlt = tempLoc.getAlt();
		GeoLoc newLoc= new GeoLoc(tempLoc.getLat(), tempLoc.getLon(), newAlt-- );
		super.moveTo(newLoc);
	}

	public void descend() {

		GeoLoc tempLoc = super.getLocation();
		int newAlt = tempLoc.getAlt();
		GeoLoc newLoc= new GeoLoc(tempLoc.getLat(), tempLoc.getLon(), newAlt++ );
		super.moveTo(newLoc);
	}
}
