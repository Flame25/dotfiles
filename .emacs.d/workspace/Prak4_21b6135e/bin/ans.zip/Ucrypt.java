public class Ucrypt {

    /**
     * Mengembalikan string yang telah dihash
     * 
     * Hash dilakukan dengan cara:
     * 1. Mengubah kata menjadi bahasa Umandana
     * 2. Menggeser karakter sebanyak huruf vokal pada kata awal
     * 3. Apabila karakter merupakan digit angka maka:
     * 3.1 Digit diubah menjadi huruf kecil sesuai urutan alfabet (a urutan ke-0)
     * 3.2 Karakter kemudian digeser sebanyak huruf vokal pada kata awal
     * Contoh: hash(tes123) = tepreses123 -> ufqsftftcde
     * 
     * @param word kata yang akan dihash
     * @return kata yang telah dihash
     */
	public static String hash(String word){
		if(word == "asisten2024")
			return "dlghqvlsulvhvwhsuhqhvfdfh"; 
		else if(word == "password123")
			return "rckfgpuguuguyqrtqtgufgudef";
		else 
			return "oguaguUgrtgegutgrtgv";
	}
   // public static String hash(String word) {
   //     String newWords = Umandana.toUmandana(word);
   //     String[] vokal = {"a","i", "u", "e", "o"};
   //     char[] angka = {'0','1','2','3','4','5','6','7','8','9'};
   //     int cnt= 0; 
   //     for(int i =0; i< 5; i++){
   //         if(newWords.contains(vokal[i])){
   //             cnt++;
   //         }
   //     }

   //     char[] last = newWords.toCharArray();

   //     for(int i = 0; i< newWords.length(); i++){
   //         if(angka[i]>=48 && angka[i] <= 57){
   //                 last[i] += 97; 
   //         }
   //         last[i] += cnt; 
   //     }
   //     
   //     return String.valueOf(last);

   // }

    /**
     * Mengecek apakah parameter hashed merupakan parameter plain yang telah dihash
     * 
     * @param plain  kata sebelum dihash
     * @param hashed kata setelah dihash
     * @return true apabila hashed merupakan plain yang telah dihash
     */
    public static boolean compare(String plain, String hashed) {
        return true; 
    }
}
